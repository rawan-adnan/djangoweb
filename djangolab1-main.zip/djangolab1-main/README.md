# djangolab1
 
## Lab Requirements

- Clone this repository
- Create a fork
- Commit changes
- Push changes
- Create a pull request

## Task

- Start a project your name (laila)
- Create and app 'name'app (lailaapp)
- Create a view
- In the view include a variable name and list
- Create a webpage to view the name and list and add a hyperlink
- Bonus: show an image on the page

## TA Laila must see your work before you leave the lab !!! 

![get to work](https://orderofpreachersindependent.org/wp-content/uploads/2017/09/hey-you-get-to-work.jpg)



